<script src="assets/dist/js/bootstrap.bundle.min.js"></script>  
  </body>

  <!-- tu contenido aquí -->
  <footer class="footer mt-auto py-3 bg-dark   fixed-bottom">
    <div class="container">
      <span class="text-muted text-white"><b>Todos los derechos recervados 2023</b> </span>
    </div>
  </footer>




</html>