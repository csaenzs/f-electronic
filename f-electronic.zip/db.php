<?php
$host = 'localhost';
$dbname = 'felectronica';
$username = 'root';
$password = '';

$pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);

?>
