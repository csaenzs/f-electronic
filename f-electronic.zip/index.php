<?php include_once('headers/header.php'); ?>

<h1>Este es el Index de la pagina </h1>
 
<?php include_once('headers/footer.php'); ?>